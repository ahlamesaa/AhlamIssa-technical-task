package com.luminous.integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuminousintegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
